# imc-logica-js
Projeto para pratica de lógica de programação. O Projeto consiste em utilizar as estruturas de programação estudadas em sala de aula.

Disponível para visualização em : https://eduardocostaprofessor.github.io/imc-javascript/